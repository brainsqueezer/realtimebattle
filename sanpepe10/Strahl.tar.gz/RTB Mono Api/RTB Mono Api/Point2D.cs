// Point2D.cs created with MonoDevelop
// User: zarovich at 17:21 14/03/2009
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;

namespace RTBMonoApi
{
	public enum Point2DOptions : int {
		COORDINATES,
		ANGLE_DISTANCE
	}
	
	public class Point2D
	{
		private double _x;
		private double _y;
		private double _angle;
		
		private double umbral = 1;
		public double x {
			get {
				return this._x;
			}
		}
		public double y {
			get {
				return this._y;
			}
		}
		public double angle {
			get {
				return this._angle;
			}
		}
		
		private double _defaultUmbral = 0.5;
		public double defaultUmbral {
			get {
				return this._defaultUmbral;
			}
			set {
				this._defaultUmbral = value;
			}
		}
		
		
		public Point2D (double x_angle, double y_distance, double angle, Point2DOptions option)
		{
			this._angle = angle % (2 * Math.PI);
			if (option == Point2DOptions.COORDINATES) {
				this._x = x_angle;
				this._y = y_distance;
			} else if (option == Point2DOptions.ANGLE_DISTANCE) {
				this._x = Math.Cos (x_angle) * y_distance;
				this._y = Math.Sin (x_angle) * y_distance;
			}
		}
		
		public double getFieldAngle ()
		{
			return Math.Acos (this._x);
		}
		
		public double getRotateAngle (double angle, Point2D robotLocation)
		{
			double pointAngle = Math.Atan2 (robotLocation.y-this.y, robotLocation.x-this.x);
			
			return (pointAngle - angle) - Math.PI;
		}
		
		public bool itsTheSame (Point2D point)
		{
			if ((point.x > this.x-umbral) && (point.x < this.x+umbral)
			    && (point.y > this.y-umbral) && (point.y < this.y+umbral)) {
				this._x = (point.x + this._x)/2;
				this._y = (point.y + this._y)/2;
				return true;
			} else return false;
		}
	}
}

