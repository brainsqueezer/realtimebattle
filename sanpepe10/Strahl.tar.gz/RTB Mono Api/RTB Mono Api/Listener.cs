// Main.cs created with MonoDevelop
// User: zarovich at 21:32 05/02/09
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//
using System;
using System.Threading;

namespace RTBMonoApi
{
	class Listener
	{
		public static Parser parser;
		
		public static void Main(string[] args)
		{
			
			Thread thr = null;
			IRobot robot = new Strahl ();
			parser = new Parser (robot);
			/**
			 * TODO: Aquí primero tengo que crear el robot
			 * configurar los parametros del RTB y mandarlo
			 * al parser tambien creado aqui mismo
			 */
			// setting robot parameters
			Console.WriteLine("RobotOption 3 0");
			
			if (thr == null) {
				thr = new Thread (Listener.Listen);
				thr.Start ();
			}
		}
		
		public static void Listen () 
		{
			string message = Console.ReadLine();
			while (message != null) {
				parser.AcceptString(message);
				Thread.Sleep(4);				
				message = Console.ReadLine();
			}
		}
		
	}
}