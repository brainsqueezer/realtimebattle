// Robot.cs created with MonoDevelop
// User: zarovich at 23:04 06/02/09
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;

namespace RTBMonoApi
{
	
	public enum MessageToRobot : int {
		UNKNOWN_MESSAGE_TO_ROBOT = -1,
		INITIALIZE,
		YOUR_NAME,
		YOUR_COLOR,
		GAME_OPTIONS,
		GAME_STARTS,
		RADAR,
		INFO,
		COORDINATES,
		ROBOT_INFO,
		ROTATION_REACHED,
		ENERGY,
		ROBOTS_LEFT,
		COLLISION,
		WARNING,
		DEAD,
		GAME_FINISHES,
		EXIT_ROBOT
	}
	
	public enum MessageFromRobot : int {
		UNKNOWN_MESSAGE_FROM_ROBOT = -1,
		ROBOT_OPTION,
		NAME,
		COLOUR,
		ROTATE,
		ROTATE_TO,
		ROTATE_AMOUNT,
		SWEEP,
		ACCELERATE,
		BRAKE,
		BREAK,
		SHOOT,
		PRINT,
		DEBUG,
		DEBUG_LINE,
		DEBUG_CIRCLE,		
	}
	
	public enum WarningMessage : int {
		UNKNOWN_MESSAGE = 0,
		PROCESS_TIME_LOW = 1,
		MESSAGE_SENT_IN_ILLEGAL_STATE = 2,
		UNKNOWN_OPTION = 3,
		OBSOLET_KEYWORD = 4,
		NAME_NOT_GIVEN = 5,
		COLOUR_NOT_GIVEN = 6
	}
	
	public enum GameOptionType : int {
		ROBOT_MAX_ROTATE = 0,
		ROBOT_CANNON_MAX_ROTATE = 1,
		ROBOT_RADAR_MAX_ROTATE = 2,
		
		ROBOT_MAX_ACCELERATION = 3,
		ROBOT_MIN_ACCELERATION = 4,
		
		ROBOT_START_ENERGY = 5,
		ROBOT_MAX_ENERGY = 6,
		ROBOT_ENERGY_LEVELS = 7,
		
		SHOT_SPEED = 8,
		SHOT_MIN_ENERGY = 9,
		SHOT_MAX_ENERGY = 10,
		SHOT_ENERGY_INCREASE_SPEED = 11,
		
		TIMEOUT = 12,
		
		DEBUG_LEVEL = 13, // 0 - no debug, 5 - highest debug level
		
		SEND_ROBOT_COORDINATES = 14 // 0 - no coordinates
		                            // 1 - coordinates are given relative the starting position
		                            // 2 - absolute coordinates
	}
	
	public enum RobotOptionType : int {
		// these options aren't available for this API, because the API motor sets up them.
		SIGNAL = 2, // 0 - no signal, > 1 - signal to send
		
		SEND_SIGNAL = 0, // boolean
		SEND_ROTATION_REACHED = 1, // 0 - no messages
		                           // 1 - messages when RotateTo and RotateAmount finished
		                           // 2 - messages also when sweep direction is changed
		
		USE_NON_BLOCKING = 3 // boolean
		                     // this option isn't relevant to use with this implementation
	}
	
	public enum ObjectType : int {
		// this is the most useful enum in this API
		NOOBJECT = -1,
		ROBOT = 0,
		SHOT = 1,
		WALL = 2,
		COOKIE = 3,
		MINE = 4,
		LAST_OBJECT_TYPE = 5
	}
	
	public enum RotableObjects : int {
		ROBOT = 1,
		CANNON = 2,
		RADAR = 4
	}
	
	public class Robot : IRobot
	{
		public virtual double maxRotateAccel {
			get {
				return 0;
			}
		}
		public virtual double maxCannonRotateAccel {
			get{
				return 0;
			}
		}
		public virtual double maxRadarRotateAccel {
			get{
				return 0;
			}
		}
		public virtual double maxAccel {
			get{
				return 0;
			}
		}
		public virtual double minAccel {
			get{
				return 0;
			}
		}
		public virtual double shotSpeed {
			get{
				return 0;
			}
		}
		public virtual double shotMinEnergy {
			get{
				return 0;
			}
		}
		public virtual double shotMaxEnergy {
			get{
				return 0;
			}
		}
		
		public virtual double x {
			get {
				return 0;
			}
		}
		
		public virtual double y {
			get {
				return 0;
			}
		}
		
		public virtual double headAngle {
			get {
				return 0;
			}
		}
		
		// methods to implement by your robot
		public Robot ()
		{
		}
		
		public virtual void Default ()
		{
			
		}
		
		public virtual void Initialize (int first)
		{
			Print("Initialize");
		}
		
		public virtual void YourName (string name)
		{
			Print("My name");
		}
		
		public virtual void YourColour (string colour)
		{
			Print("My Colour");
		}
		
		public virtual void GameOption (GameOptionType option, double val)
		{
			Print("GameOption received" + option.ToString());
		}
		
		public virtual void GameStarts ()
		{
			Print("Battle has been started");
			((IRobot) this).Default ();
		}
		
		public virtual void Radar (double distance, ObjectType objectType, double radarAngle)
		{
			Print("Object detected" + objectType.ToString());
			((IRobot) this).Default ();
		}
		
		public virtual void Info (double time, double speed, double cannonAngle)
		{
			Print("Info received");
			((IRobot) this).Default ();
		}
		
		public virtual void Coordinates (double x, double y, double angle)
		{
			Print("My coordinates");
			((IRobot) this).Default ();
		}
		
		public virtual void RobotInfo (double energyLevel, int teamMate)
		{
			Print("Enemy info");
			((IRobot) this).Default ();
		}
		
		public virtual void RotationReached (RotableObjects whatHasReached)
		{
			Print("I finished my rotation" + whatHasReached.ToString());
			((IRobot) this).Default ();
		}
		
		public virtual void Energy (double energy)
		{
			Print("My energy");
			((IRobot) this).Default ();
		}
		
		public virtual void RobotsLeft (int numberOfRobots)
		{
			Print("X Robots left");
		}
		
		public virtual void Collision (ObjectType collisionType, double relativeAngle)
		{
			Print("I crash" + collisionType.ToString());
			((IRobot) this).Default ();
		}
		
		public virtual void Warning (WarningMessage warningType, string message)
		{
			Print("Warning");
		}
		
		public virtual void Dead ()
		{
			Print("Oh no... i'm very harmed.. i'll die");
		}
		
		public virtual void GameFinishes ()
		{
			Print("I survived");
		}
		
		public virtual void ExitRobot ()
		{
			Print("Bye bye");
		}
		
		// methos to give orders for your robot
		public void SetRobotOption (RobotOptionType robotOption, int val)
		{
			Console.WriteLine ("RobotOption " + (int) robotOption + " " + val);
		}
		
		
		public void SetName (string name)
		{
			Console.WriteLine ("Name " + name);
		}
		
		public void SetColour (string colour1, string colour2)
		{
			Console.WriteLine ("Colour " + colour1 + " " + colour2);
		}
		
		public void Rotate (RotableObjects objectToRotate, double val)
		{
			Console.WriteLine ("Rotate " + (int) objectToRotate + " " + val);
		}
		
		public void RotateTo (RotableObjects objectToRotate, double velocity, double endAngle)
		{
			if (objectToRotate == RotableObjects.ROBOT) {
				// throw exception
			} else {
				Console.WriteLine ("RotateTo " + (int) objectToRotate + " " + velocity + " " + endAngle); 
			}
		}
		
		public void RotateAmount (RotableObjects objectToRotate, double velocity, double angle)
		{
			Console.WriteLine ("RotateAmount " + (int) objectToRotate + " " + velocity + " " + angle);
		}
		
		public void Sweep (RotableObjects objectToRotate, double velocity, 
		                   double leftAngle, double rightAngle)
		{
			Console.WriteLine ("Sweep " + (int) objectToRotate + " " + velocity + " " +
			                   leftAngle + " " + rightAngle);
		}
		
		public void Accelerate (double val)
		{
			Console.WriteLine ("Accelerate " + val);
		}
		
		public void Brake (double val)
		{
			Console.WriteLine ("Brake " + val);
		}
		
		public void Shoot (double energy)
		{
			Console.WriteLine ("Shoot " + energy);
		}
				
		public void Print (string str)
		{
			Console.WriteLine("Print " + str);
		}
		
		public void Debug (string message)
		{
			Console.WriteLine ("Debug " + message); 
		}
		
		public void DebugLine (double angle1, double radius1, 
		                       double angle2, double radius2)
		{
			Console.WriteLine ("DebugLine " + angle1 + " " + radius1 + " "
			                   + angle2 + " " + radius2);
		}
		
		public void DebugCircle (double centerAngle, double centerRadius, double circleRadius)
		{
			Console.WriteLine ("DebugCircle " + centerAngle + " " + centerRadius + " "
			                   + circleRadius);
		}
	}
}
