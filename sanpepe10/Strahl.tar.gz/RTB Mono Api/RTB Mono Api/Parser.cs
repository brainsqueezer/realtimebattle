// Parser.cs created with MonoDevelop
// User: zarovich at 22:28 05/02/09
//
// 
//

/**
 * This class accepts events from Listener and reads the event string.
 * Then it launchs method that corresponds with event received.
 */

using System;

namespace RTBMonoApi
{
	
	public class Parser
	{
		private IRobot robot;
		
		public Parser(IRobot robot)
		{
			this.robot = robot;
		}
		
		public void AcceptString (string message)
		{
			string[] components;
			char[] separators = {' '};
			components = message.Split(separators);
			switch (components[0])
			{
			case "Initialize": robot.Initialize (int.Parse(components[1])); break;
			case "YourName": robot.YourName (components[1]); break;
			case "YourColour": robot.YourColour (components[1]); break;
			case "GameOption": robot.GameOption ((GameOptionType)int.Parse(components[1]), 
				                                 double.Parse(components[2])); break;
			case "GameStarts": robot.GameStarts (); break;
			case "Radar": robot.Radar (double.Parse(components[1]),
				                       (ObjectType)int.Parse(components[2]),
				                       double.Parse(components[3])); break;
			case "Info": robot.Info (double.Parse(components[1]),
				                     double.Parse(components[2]),
				                     double.Parse(components[3])); break;
			case "Coordinates": robot.Coordinates (double.Parse(components[1]),
				                                   double.Parse(components[2]),
				                                   double.Parse(components[3])); break;
			case "RobotInfo": robot.RobotInfo (double.Parse(components[1]),
				                               int.Parse(components[2])); break;
			case "RotationReached": robot.RotationReached ((RotableObjects)int.Parse(components[1])); break;
			case "Energy": robot.Energy (double.Parse(components[1])); break;
			case "RobotsLeft": robot.RobotsLeft (int.Parse(components[1])); break;
			case "Collision": robot.Collision ((ObjectType)int.Parse(components[1]),double.Parse(components[2])); break;
			case "Warning": robot.Warning ((WarningMessage)int.Parse(components[1]), components[2]); break;
			case "Dead": robot.Dead (); break;
			case "GameFinishes": robot.GameFinishes (); break;
			case "ExitRobot": robot.ExitRobot (); break;
			default: robot.Default (); break;
			}
		}
		
	}
}
