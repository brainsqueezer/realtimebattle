// Radar.cs created with MonoDevelop
// User: zarovich at 22:07 12/03/2009
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;

namespace RTBMonoApi
{
	
	
	public class RadarElmnt : IRobotElement
	{
		private Robot robot;
		private double time;
		private bool rotating;
		
		public bool withTarget {
			get {
				return false;
			}
		}
		
		public RadarElmnt (Robot robot)
		{
			this.robot = robot;
			this.rotating = false;
		}
		
		public void Radar (double distance, ObjectType objectType, double radarAngle)
		{
			//robot.Print ("Giro de radar: " + (radarAngle*180)/Math.PI);
			//robot.Print ("Angulo real: " + radarAngle%(Math.PI*2));
			if (!this.rotating) {
				if (objectType == ObjectType.ROBOT) {
					robot.Print ("Angulo izquierdo: " + (robot.headAngle+((Math.PI/20)*distance)%Math.PI));
					robot.Print ("Angulo derecho: " + (robot.headAngle-((Math.PI/20)*distance)%Math.PI));
					robot.Sweep (RotableObjects.RADAR, robot.maxRadarRotateAccel,
					             (robot.headAngle+(Math.PI/20))%Math.PI, 
					             (robot.headAngle-(Math.PI/20))%Math.PI);
					this.rotating = true;
				}
			}
		}
		
		public void Info (double time, double speed, double cannonAngle)
		{
			this.time = time;
			Default ();
		}
		
		public void RotationReached (RotableObjects whatWasRotated)
		{
			if (whatWasRotated == RotableObjects.RADAR) 
				this.rotating = false;
		}
		
		public void Collision (ObjectType collisionType, double relativeAngle)
		{
			Default ();
		}
		
		public void Default ()
		{
			if (!this.rotating) {
				this.robot.Rotate (RotableObjects.RADAR, robot.maxRadarRotateAccel);
			}
		}
		
		public void FinishYourObjetives ()
		{
		}
		
		public void Coordinates (double x, double y, double angle)
		{
		}
	}
}
