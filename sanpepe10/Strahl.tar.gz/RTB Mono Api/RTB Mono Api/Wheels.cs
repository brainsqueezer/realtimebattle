// Wheels.cs created with MonoDevelop
// User: zarovich at 19:17 12/03/2009
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;

using System.Collections;
using System.Collections.Generic;

namespace RTBMonoApi
{
	
	
	public class Wheels : IRobotElement
	{
		private Robot robot;
		private bool rotatingTo;
		private double targetX;
		private double targetY;
		private ObjectType targetType;
		private double time;
		
		private List<Point2D> target; // to eat cookies
		private Point2D emergencyTarget; // to avoid walls
		private Point2D enemyTarget; // to follow an enemy
		
		private const double PI = Math.PI; //pipiiiiiiiiiii
		
		private double lastDefaultAngle = 0;
		
		public bool withTarget {
			get {
				return (this.target.Count > 0);
			}
		}
		
		public Wheels(Robot robot)
		{
			this.robot = robot;
			this.rotatingTo = false;
			this.targetType = ObjectType.NOOBJECT;
			this.target = new List<Point2D> ();
			this.emergencyTarget = null;
			this.enemyTarget = null;
		}
		
		public void Radar (double distance, ObjectType objectType, double radarAngle)
		{
			double ra = radarAngle%(2*Math.PI);

			switch (objectType) 
			{
			case ObjectType.WALL: {
				/**
				 * TODO: Esto mejor hacerlo con coordenadas del escenario.
				 * Sabiendo el tamaño, del escenario, evitar que pise determinadas
				 * zonas, fijando un punto de destino alejado en 3 unidades de la pared.
				 * Con máxima prioridad. Las galletas cerca de pared deberán ser eliminadas.
				 */
				if ((distance < 3)) {
					// hacer que la detecte en cualquier direccion y luego meterle un 
					// aviso para que pueda acabar la maniobra.
					if (this.emergencyTarget == null) {
						Point2D point = new Point2D (0, 0, 0, Point2DOptions.COORDINATES);
						this.emergencyTarget = point;
						robot.Brake (1);
					}
					
				}
			} break;
			case ObjectType.COOKIE: {
				this.targetX = Math.Cos(Math.Abs(ra)+robot.headAngle)*distance + robot.x;
				this.targetY = Math.Sin(Math.Abs(ra)+robot.headAngle)*distance + robot.y;
				Point2D point = new Point2D (this.targetX, this.targetY,
				                             Math.Abs(ra)+robot.headAngle, 
				                             Point2DOptions.COORDINATES);
				
				if (this.target.Count == 0) {
					robot.Brake (0.5);
					robot.RotateAmount (RotableObjects.ROBOT, robot.maxRotateAccel, 
					                    point.getRotateAngle(robot.headAngle, 
					                                         new Point2D (robot.x, robot.y, 0, 
					                                                      Point2DOptions.COORDINATES)));
					this.rotatingTo = true;
				} else if (!this.rotatingTo) this.FinishYourObjetives ();
				if (targetRepeated (point) == null) {
					this.target.Add (point);
					this.targetType = ObjectType.COOKIE;
				}
			} break;
			case ObjectType.ROBOT: {
				/*this.targetX = Math.Cos(Math.Abs(ra)+robot.headAngle)*distance + robot.x;
				this.targetY = Math.Sin(Math.Abs(ra)+robot.headAngle)*distance + robot.y;
				Point2D point = new Point2D (this.targetX, this.targetY,
				                             Math.Abs(ra)+robot.headAngle, 
				                             Point2DOptions.COORDINATES);
				
				if (this.target.Count == 0) {
					robot.Brake (0.5);
					robot.RotateAmount (RotableObjects.ROBOT, robot.maxRotateAccel, 
					                    point.getRotateAngle(robot.headAngle, 
					                                         new Point2D (robot.x, robot.y, 0, 
					                                                      Point2DOptions.COORDINATES)));
					this.rotatingTo = true;
				} else if (!this.rotatingTo) this.FinishYourObjetives ();
				if (targetRepeated (point) == null) {
					this.enemyTarget = point;
				}*/
			} break;
			default: Default (); break;
			}
		}
		
		public void Info (double time, double speed, double cannonAngle)
		{
			this.time = time;
			Default ();
		}
		
		public void RotationReached (RotableObjects whatWasRotated)
		{
			if (whatWasRotated == RotableObjects.ROBOT) {
				if (this.targetType == ObjectType.COOKIE) {
					robot.Accelerate (robot.maxAccel);
					this.FinishYourObjetives ();
					this.rotatingTo = false;
				} else if (this.emergencyTarget != null) {
					robot.Brake (0);
					robot.Accelerate (robot.maxAccel/2);
					this.rotatingTo = false;
				} else {
					robot.Accelerate (robot.maxAccel);
					this.rotatingTo = false;
				}
			}
		}
		
		public void Collision (ObjectType collisionType, double relativeAngle)
		{
			if (collisionType == ObjectType.COOKIE) {
				if (this.target.Count > 0)
					this.target.RemoveAt (0);
			} else if (collisionType == ObjectType.SHOT) {
				if ((relativeAngle > Math.PI-30) && (relativeAngle < Math.PI + 30)) {
					robot.Brake (1);
					robot.Accelerate (0);
					robot.RotateAmount (RotableObjects.ROBOT, robot.maxRotateAccel, Math.PI/4);
				}
			}
			Default ();
		}
		
		public void Coordinates (double x, double y, double angle)
		{
			Point2D point = new Point2D (x, y, angle, Point2DOptions.COORDINATES);
			Point2D founded;
			if ((this.emergencyTarget != null) && 
			    (x > -3) && (x < 3) && (y > -3) && (y < 3)) {
				this.emergencyTarget = null;
			} else if ((founded = targetRepeated (point)) != null) {
				this.target.Remove (founded);
				robot.Brake (0.8);
			}
		}
		
		public void Default ()
		{
			Random rd = new Random ();
			
			if (!(this.withTarget || rotatingTo)) {
				double angleVar = rd.NextDouble ();
				
				if (this.lastDefaultAngle < 0)
					angleVar = angleVar + 0.5;
				else angleVar = angleVar - 0.5;
				this.lastDefaultAngle = angleVar;
				robot.Brake (0);
				robot.RotateAmount (RotableObjects.ROBOT, robot.maxRotateAccel, PI*angleVar*2);
				this.rotatingTo = true;
				robot.Accelerate (1);
			} else if (this.withTarget) this.FinishYourObjetives ();
		}
		
		// this method fixes robot direction
		public void FinishYourObjetives ()
		{
			if (this.emergencyTarget != null) {
				robot.RotateAmount (RotableObjects.ROBOT, robot.maxRotateAccel,
				                    this.emergencyTarget.getRotateAngle (robot.headAngle, 
				                                                         new Point2D (robot.x, robot.y,
				                                                                      0, Point2DOptions.COORDINATES)));
			} else if (this.withTarget) {
				robot.Brake (0);
				Point2D point = (Point2D)this.target.ToArray ().GetValue (0);
				robot.RotateAmount (RotableObjects.ROBOT, robot.maxRotateAccel, 
				                    point.getRotateAngle (robot.headAngle, new Point2D (robot.x, robot.y, 
				                                                                        0, Point2DOptions.COORDINATES)));
				robot.Accelerate (robot.maxAccel*3/5);
				this.rotatingTo = true;
			}
		}
		
		public Point2D targetRepeated (Point2D point)
		{
			IEnumerator iter = this.target.GetEnumerator ();
			while (iter.MoveNext ()) {
				Point2D element = (Point2D) iter.Current;
				if (element.itsTheSame (point)) {
					return element;
				}
			}
			return null;
		}
	}
}
