// IRobotWheels.cs created with MonoDevelop
// User: zarovich at 17:50 12/03/2009
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;

namespace RTBMonoApi
{
	
	
	public interface IRobotElement
	{
		bool withTarget {
			get;
		}
		
		void Radar (double distance, ObjectType objectType, double radarAngle);
		void Info (double time, double speed, double cannonAngle);
		void RotationReached (RotableObjects whatWasRotated);
		void Collision (ObjectType collisionType, double relativeAngle);
		void Default ();
		void FinishYourObjetives ();
		void Coordinates (double x, double y, double angle);
	}
}
