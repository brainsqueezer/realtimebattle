// Strahl.cs created with MonoDevelop
// User: zarovich at 00:02 07/02/09
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;
using System.Collections;
using System.Collections.Generic;

namespace RTBMonoApi
{
	
	
	public class Strahl : Robot
	{
		// game options properties
		private double _maxRotateAccel;
		private double _maxCannonRotateAccel;
		private double _maxRadarRotateAccel;
		private double _maxAccel;
		private double _minAccel;
		private double _robotStartEnergy;
		private double _robotMaxEnergy;
		private double _robotEnergyLevels;
		private double _shotSpeed;
		private double _shotMinEnergy;
		private double _shotMaxEnergy;
		private double _timeout;
		private double _debugLevel;
		private double _sendRobotCoordinates;
		
		// only accesible, useful attributes for robot elements
		public override double maxRotateAccel {
			get {
				return this._maxRotateAccel;
			}
		}
		
		public override double maxCannonRotateAccel {
			get {
				return this._maxCannonRotateAccel;
			}
		}
		
		public override double maxRadarRotateAccel {
			get {
				return this._maxRadarRotateAccel;
			}
		}
		
		public override double maxAccel {
			get {
				return this._maxAccel;
			}
		}
		
		public override double minAccel {
			get {
				return this._minAccel;
			}
		}
		
		public override double shotSpeed {
			get {
				return this._shotSpeed;
			}
		}
		
		public override double shotMinEnergy {
			get {
				return this._shotMinEnergy;
			} 
		}
		
		public override double shotMaxEnergy {
			get {
				return this._shotMaxEnergy;
			}
		}
		
		// useful constans
		private const double PI = Math.PI; //pipiiiiiiiiiii
		
		//robot state properties
		private double _x;
		private double _y;
		private double _headAngle;
		private double _energy;
		
		public override double x {
			get {
				return this._x;
			}
		}
		
		public override double y {
			get {
				return this._y;
			}
		}
		
		public override double headAngle {
			get {
				return this._headAngle;
			}
		}
		
		public double energy {
			get {
				return this._energy;
			}
		}
		
		//robot elements
		private List<IRobotElement> elements = new List<IRobotElement>();
		
		public override void Initialize (int first)
		{
			if (first == 1) {
				this.SetName("Strahl");
				this.SetColour("ff0000", "aa6666");
				this.SetRobotOption (RobotOptionType.SEND_ROTATION_REACHED, 1);
			}

			// assembling elements
			elements.Add(new Wheels(this));
			elements.Add(new RadarElmnt(this));
			elements.Add(new Cannon(this));
		}

		public override void GameStarts ()
		{
		}

		public override void RotationReached (RotableObjects whatHasReached)
		{
			IEnumerator iterator = elements.GetEnumerator ();
			
			while (iterator.MoveNext ()) {
				IRobotElement element = (IRobotElement)iterator.Current;
				element.RotationReached (whatHasReached);
			}
		}
		
		public override void Collision (ObjectType collisionType, double relativeAngle)
		{
			IEnumerator iterator = elements.GetEnumerator ();
			while (iterator.MoveNext ()) {
				IRobotElement element = (IRobotElement)iterator.Current;
				element.Collision (collisionType, relativeAngle);
			}
		}
		
		public override void Radar (double distance, ObjectType objectType, double radarAngle)
		{
			IEnumerator iterator = elements.GetEnumerator ();
			
			while (iterator.MoveNext ()) {
				IRobotElement element = (IRobotElement)iterator.Current;
				element.Radar (distance, objectType, radarAngle);
			}
		}
		
		public override void Info (double time, double speed, double cannonAngle)
		{
			IEnumerator iterator = elements.GetEnumerator ();
			
			while (iterator.MoveNext ()) {
				IRobotElement element = (IRobotElement)iterator.Current;
				if (!element.withTarget) {
					element.Info (time, speed, cannonAngle);
				}
			}
		}

		public override void Coordinates (double x, double y, double angle)
		{
			this._x = x;
			this._y = y;
			this._headAngle = angle % (2 * Math.PI);
			
			IEnumerator iterator = elements.GetEnumerator ();
			while (iterator.MoveNext ()) {
				IRobotElement element = (IRobotElement)iterator.Current;
				element.Coordinates (x, y, angle);
			}
		}
		
		public override void Energy (double energy)
		{
			this._energy = energy;
		}


		public override void Default ()
		{
			IEnumerator iterator = elements.GetEnumerator ();
			
			while (iterator.MoveNext ()) {
				IRobotElement element = (IRobotElement)iterator.Current;
				if (!element.withTarget) {
					element.Default ();
				}
			}
		}
		
		public override void GameOption (GameOptionType option, double val)
		{
			base.GameOption (option, val);
			switch (option) 
			{ 
			case GameOptionType.ROBOT_MAX_ROTATE: this._maxRotateAccel = val; break;
			case GameOptionType.ROBOT_MAX_ACCELERATION: this._maxAccel = val; break;
			case GameOptionType.ROBOT_MIN_ACCELERATION: this._minAccel = val; break;
			case GameOptionType.ROBOT_RADAR_MAX_ROTATE: this._maxRadarRotateAccel = val; break;
			case GameOptionType.DEBUG_LEVEL: this._debugLevel = val; break;
			case GameOptionType.ROBOT_CANNON_MAX_ROTATE: this._maxCannonRotateAccel = val; break;
			case GameOptionType.ROBOT_ENERGY_LEVELS: this._robotEnergyLevels = val; break;
			case GameOptionType.ROBOT_MAX_ENERGY: this._robotMaxEnergy = val; break;
			case GameOptionType.ROBOT_START_ENERGY: this._robotStartEnergy = val; break;
			case GameOptionType.SEND_ROBOT_COORDINATES: this._sendRobotCoordinates = val; break;
			case GameOptionType.SHOT_MAX_ENERGY: this._shotMaxEnergy = val; break;
			case GameOptionType.SHOT_MIN_ENERGY: this._shotMinEnergy = val; break;
			case GameOptionType.SHOT_SPEED: this._shotSpeed = val; break;
			case GameOptionType.TIMEOUT: this._timeout = val; break;
			} 
		}

		
		public override void Warning (WarningMessage warningType, string message)
		{
			base.Warning (warningType, message);
			this.Print (warningType.ToString() + message);
		}

	}
}
