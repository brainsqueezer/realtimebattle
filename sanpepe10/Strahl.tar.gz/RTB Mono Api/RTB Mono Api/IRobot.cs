// IRobot.cs created with MonoDevelop
// User: zarovich at 21:13 06/02/09
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

/**
 * This intarface provides a list of methods that robot should implement to
 * listen RTB events.
 */
using System;

namespace RTBMonoApi
{
	
	public interface IRobot
	{
		void Default (); // default action. it's always exec
		void Initialize (int first); // it's the first session of a tournament?
		void YourName (string name); // it tells you your robot name
		void YourColour (string colour); // it tells you your robot color
		void GameOption (GameOptionType option, double val);
		void GameStarts (); // the game starts
		void Radar (double distance, ObjectType objectType, double radarAngle); // it updates your radar info
		void Info (double time, double speed, double cannonAngle); // some info from robot and game status
		void Coordinates (double x, double y, double angle);
		void RobotInfo (double energyLevel, int teamMate); // info from detected bot
		void RotationReached (RotableObjects whatHasReached);
		void Energy (double energy);
		void RobotsLeft (int numberOfRobots);
		void Collision (ObjectType collisionType, double relativeAngle);
		void Warning (WarningMessage warningType, string message);
		void Dead ();
		void GameFinishes ();
		void ExitRobot ();
	}
}
