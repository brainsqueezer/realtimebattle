// Cannon.cs created with MonoDevelop
// User: zarovich at 22:19 12/03/2009
//
// To change standard headers go to Edit->Preferences->Coding->Standard Headers
//

using System;

namespace RTBMonoApi
{
	
	
	public class Cannon : IRobotElement
	{
		private Robot robot;
		private double umbralDistance = 4;
		private double actualRadarAngle;
		private bool staticTarget;
		private Point2D staticTargetXY;
		
		public bool withTarget {
			get {
				return false;
			}
		}
		
		public Cannon(Robot robot)
		{
			this.robot = robot;
			this.staticTarget = false;
		}
		
		public void Radar (double distance, ObjectType objectType, double radarAngle)
		{
			this.actualRadarAngle = radarAngle%(2*Math.PI);
			
			if (objectType == ObjectType.ROBOT) {
				if (distance < this.umbralDistance) {
					robot.Shoot (robot.shotMaxEnergy);
				} else if (distance < this.umbralDistance*2) {
					robot.Shoot (robot.shotMaxEnergy/2);
				} else if (distance < this.umbralDistance*3) {
					for (int i = 0; i < 10; i++)  
						robot.Shoot (robot.shotMinEnergy);
				}
			} else if (objectType == ObjectType.MINE) {
				this.staticTarget = true;
				this.staticTargetXY = new Point2D (robot.x, robot.y, 
				                                   Math.Abs (actualRadarAngle)+robot.headAngle, 
				                                   Point2DOptions.COORDINATES);
				for (int i = 0; i < 10; i++) {
					robot.Shoot (robot.shotMinEnergy);
				}
			}
			Default ();
		}
		
		public void Info (double time, double speed, double cannonAngle)
		{
			Default ();
		}
		
		public void RotationReached (RotableObjects whatWasRotated)
		{
			if (whatWasRotated == RotableObjects.CANNON)
				Default ();
		}
		
		public void Collision (ObjectType collisionType, double relativeAngle)
		{
			Default ();
		}
		
		public void Default ()
		{
			if (!this.staticTarget) {
				this.robot.RotateTo (RotableObjects.CANNON, robot.maxCannonRotateAccel, this.actualRadarAngle);
			}
		}
		
		public void FinishYourObjetives ()
		{
			Default ();
		}
		
		public void Coordinates (double x, double y, double angle)
		{
		}
	}
}
