/* This example is part of RTBApi
 * Copyright (C) 1998 Ruben <ryu@mundivia.es>, 2007 Leandro <leandro DOT regueiro AT gmail DOT com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
#include <stdio.h>
#include <stdlib.h>
#include "rtbapi.h"

#define PI 3.14159265358979323846
#define AMOUNT 0.4


/*
Para compilar:
               gcc -Wall -combine parser.c rtbapi.c robot_smaug.c -o smaug.robot && cp smaug.robot /usr/lib/realtimebattle/Robots/ && chmod 777 /usr/lib/realtimebattle/Robots/smaug.robot
*/

double game_options[32]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

void game_option(game_option_type type, double value) {
  game_options[type]=value;
}

void exit_robot() {
    exit(0);
}

void initialize(int i) {
   RobotOption(SEND_ROTATION_REACHED,1);
   if (i==1) {
      Name("Smaug SP10");
      Colour(0xff8800, 0x0088ff);
   }
}

void Evitar_parede (double distance, object_type observed) {
   if (observed==IS_WALL && distance<3.5) {  
      Rotate(ROTATE_ROBOT,-game_options[ROBOT_MAX_ROTATE]);
      Brake(1.0);
   }
}


void Disparar_inimigo (double distance) {
   Shoot(100 / distance);
   if (distance < 3.5) {
      Shoot(game_options[SHOT_MAX_ENERGY]);
      Shoot(game_options[SHOT_MAX_ENERGY]);
      Shoot(game_options[SHOT_MAX_ENERGY]);
      Shoot(game_options[SHOT_MAX_ENERGY]*2/3);
   }
   else if (distance < 10) {
         Shoot(game_options[SHOT_MAX_ENERGY]);
         Shoot(game_options[SHOT_MAX_ENERGY]/2);
      }
}


void Defensa_perimetral (object_type observed) { 
   if (observed==IS_MINE) Shoot(game_options[SHOT_MIN_ENERGY]);
}


void Pillar_galleta (double distance, object_type observed) {
   if (observed==IS_COOKIE && distance>2.0) {
      Shoot(game_options[SHOT_MIN_ENERGY]);
   }
}



void radar(double distance, object_type observed,double angle) {
static int rotating=1;
static int direction=+1;
static int not_visible=0;
static int searching=0;
static int accelerating=0;
static float searching_pos=0.0;
static double accel=0.0;

   if (observed == IS_ROBOT) {
      
      Disparar_inimigo(distance);
      rotating = 0;
      not_visible = 0;
      searching = 0;
      accel = 0;
      searching_pos = 0;
      accelerating = 0;
      Brake(1.0);
   }
   else {
   
      if (rotating==0) {
         rotating = 1;
         searching = 1;
         searching_pos = 0.0;
      }

      Defensa_perimetral(observed);      
      Pillar_galleta(distance, observed);

      if (rotating && searching_pos >= 300) {
         searching_pos = 0.0;
         direction =- direction;
         Brake(0.0);
         Accelerate(game_options[ROBOT_MAX_ACCELERATION] / 2);
         accelerating = 1;
         Evitar_parede(distance, observed);
      }

      if (searching==0 || searching==3) {
         accel+=0.1;
      }

      if (searching>0 && searching<3) {
         Brake(1.0);
         not_visible++;
         if (not_visible>(1/AMOUNT)*10*searching) {
            not_visible=0;
            direction=-direction;
            searching++;
         }         
      }
   }

   if (rotating) {
      Rotate(ROTATE_ROBOT, direction*(AMOUNT+accel));
      searching_pos+=direction*(AMOUNT+accel);
   }
}




int main() {
   /* Initializing Callbacks */
   Initialize=initialize;
   Radar=radar;
   ExitRobot=exit_robot;
   GameOption=game_option;

   /* Calling parser */
   Scanner();

   /* Ouch, parser exited, there was an error */
   return 1;
}
