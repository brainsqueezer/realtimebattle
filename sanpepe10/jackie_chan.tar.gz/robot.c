//Autor: Sergio Padin Varela
//nombre del robot: Jackie Chan

//Compilacion:   gcc -combine parser.c rtbapi.c robot.c -o Jackie_Chan.robot
//Licencia GPL

#include <stdio.h>
#include "rtbapi.h"
#define PI 3.141592653
int vueltas = 0;
int anterior = -1;
void controla_pared(double distance, double angle) //Esto tb o hay que mirar dependendo do angulo
{

   
   if (distance < 10)
      {
         //RotateTo(ROTATE_RADAR + ROTATE_CANNON, 10, 0);
         if (vueltas == 100) vueltas = 0;
         if (((vueltas % 2)==0) || ((vueltas % 5) == 0))
         {
            if (distance <= 2) 
               {
                  if (angle < PI/4)
                     {
                        Brake(1);
                        Brake(1);
                        Brake(1);
                     }
                  //else Shoot(1);
                  Rotate(ROTATE_RADAR + ROTATE_CANNON, 10);
               }
            else if (distance < 4) 
               {
                  if (angle < PI/4)
                     {
                        Brake(0.7);
                        Brake(0.7);
                        Brake(0.7);
                     }
                  //else Shoot(1);
               }
            else
               {
                  Brake(0.3);
               }

            RotateAmount(ROTATE_ROBOT, 4, -PI*1.5);
            //RotateAmount(ROTATE_RADAR, 4, -PI*1.5);
            RotateAmount(ROTATE_ROBOT, 4, -PI*1.5);
            RotateAmount(ROTATE_ROBOT, 4, -PI*1.5);
            //RotateTo(ROTATE_RADAR, 4, 0);
            vueltas = vueltas+2;
            
         }
         else 
         {
            if (distance <= 1) Brake(1);
            else if (distance < 5)
               {
                  Brake(0.7);
                  
               }
            else
               {
                  Brake(0.3);
             
               }

            RotateAmount(ROTATE_ROBOT, 4, PI*0.6);
            //RotateAmount(ROTATE_RADAR, 4, PI*0.2);
            RotateAmount(ROTATE_ROBOT, 4, PI*0.6);
            RotateAmount(ROTATE_ROBOT, 4, PI*0.6);
            //RotateTo(ROTATE_RADAR, 4, 0);
            vueltas = vueltas - 1;
            Accelerate(1);
         }
      }
   else 
      {
         Accelerate(4);
         //RotateTo(ROTATE_RADAR, 4, 0);
      }


}

void controla_robots(double distance, double angle)
{
   Accelerate(0.5);
   //RotateAmount(ROTATE_ROBOT, 3, PI/4);
   if (distance < 2)
   {
      RotateAmount(ROTATE_CANNON + ROTATE_RADAR, 4, 0);
      Shoot((1/distance)*100);
      Shoot((1/distance)*100);
      Shoot((1/distance)*100);
      Shoot((1/distance)*100);
      //Rotate(ROTATE_RADAR + ROTATE_CANNON, 10);
      Accelerate(3);
   }
   else if (distance < 5)
   {
      RotateAmount(ROTATE_CANNON + ROTATE_RADAR, 4, 0);
      Shoot((1/distance) * 100);
      Shoot((1/distance) * 100);
      Shoot((1/distance) * 100);
      Shoot((1/distance) * 100);
      Shoot((1/distance) * 100);
      //Rotate(ROTATE_RADAR + ROTATE_CANNON, 10);
      Accelerate(3);
   }
   else
   {
      RotateAmount(ROTATE_CANNON + ROTATE_RADAR, 4, 0);
      Shoot((1/distance) * 100);
      Shoot((1/distance) * 100);
      Shoot((1/distance) * 100);
      Shoot((1/distance) * 100);
      Shoot((1/distance) * 100);
      //Rotate(ROTATE_RADAR + ROTATE_CANNON, 10);
      Accelerate(3);      
   }
   
}

void radar(double distance, object_type observed, double angle)
{

   Accelerate(0.5);
//Rotate(ROTATE_RADAR + ROTATE_CANNON, 10);
   Rotate(ROTATE_ROBOT, 3);
   if (observed == IS_WALL)
   {
      controla_pared(distance, angle);
      //if ((anterior != IS_ROBOT) && (anterior != IS_COOKIE)) Rotate(ROTATE_RADAR + ROTATE_CANNON, 10);
   }
   if (observed == IS_ROBOT)
   {
      
      anterior = IS_ROBOT;
      controla_robots(distance, angle);
   }
   if (observed == IS_COOKIE)
   {
      anterior = IS_COOKIE;
      RotateTo(ROTATE_RADAR + ROTATE_CANNON, 10, 0);
      RotateAmount(ROTATE_ROBOT, 3, 0);
      Accelerate(10);
   }
   if (observed == IS_MINE)
   {
      Shoot(1);
      Shoot(1);
      Shoot(1);
   }
   else Rotate(ROTATE_RADAR + ROTATE_CANNON, 10);
               
}

void exit_robot()
{
    exit(1);
}
        
int main()
{
/* Initializing Callbacks */

Name("Jackie Chan");
Colour(0x00ff00,0x00ff00);

Radar=radar;
ExitRobot=exit_robot;

/* Calling parser */
Scanner();

/* Ouch, parser exited, there was an error */
return 1;
}
   	
	

