/* This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
#include "rtbapi.h"

#define PI 3.14159265359

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <time.h>

int visto = 0;
int timeoutVisto = 0;
int shooted=0;


/* Autor: Sergio Baamonde
Basado en el archivo que acompaña a RTBApi creado por Ruben <ryu@mundivia.es> 
con fragmentos de Bahamut (por Victor Portela) y Smaug SP09 (por Leandro Regueiro),
obtenidos de la página http://rtb.belay.es/?page_id=252 */


void initialize(int i)
{
    RobotOption(SEND_ROTATION_REACHED,1);
    if (i==1) 
    {
        Name("Lancelot Albion");
        Colour(0x00ff00,0x00ff00);
    }
}

#define AMOUNT 0.4

double game_options[32]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

void game_option(game_option_type type, double value)
{
  game_options[type]=value;
}

double parseAng (double ang){
	return ((ang/(2*PI))-floor((ang/(2*PI))))*2*PI;
}

void disparo_maximo() {
    Shoot(game_options[SHOT_MAX_ENERGY]);
}

void disparo_minimo() {
    Shoot(game_options[SHOT_MIN_ENERGY]);
}

void alinear() {
    double vel;
    if (ROBOT_CANNON_MAX_ROTATE < ROBOT_RADAR_MAX_ROTATE)
        vel = ROBOT_RADAR_MAX_ROTATE;
    else
        vel =ROBOT_CANNON_MAX_ROTATE;
    RotateTo(ROTATE_CANNON+ROTATE_RADAR, vel, 0);
}

void escapar() {
    Brake(0.0);
    Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);
    Accelerate(game_options[ROBOT_MAX_ACCELERATION]/4);
}

void collision (object_type collide, double angle){
    switch (collide) {
        case IS_WALL: {
			Brake(1.0);
			Accelerate(+game_options[ROBOT_MAX_ACCELERATION]/6);
			if (parseAng(angle)<PI)
				RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-PI/2);
			else 
				RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],PI/2);
			break;
		}
		case IS_ROBOT: {
            Brake(1.0);
            escapar();
	        break;
		}
		case IS_SHOT: {
				Accelerate(+game_options[ROBOT_MAX_ACCELERATION]/6);
				RotateAmount(ROTATE_ROBOT,100,PI);
				break;
		}
	}
}

void seguir (double distance,double angle){
	Brake(0.0);
	Accelerate(game_options[ROBOT_MAX_ACCELERATION]/2);
	RotateTo (ROTATE_CANNON, +game_options[ROBOT_CANNON_MAX_ROTATE],angle);
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],angle);
	alinear();
}

void Disparar (double distance) {
   Shoot(100 / distance);
   if (distance < 3.5) {
      Shoot(game_options[SHOT_MAX_ENERGY]/2);
      Shoot(game_options[SHOT_MAX_ENERGY]/2);
      Shoot(game_options[SHOT_MAX_ENERGY]/2);
      Shoot(game_options[SHOT_MAX_ENERGY]/2);
   }
   else if (distance < 10) {
         Shoot(game_options[SHOT_MAX_ENERGY]/4);
         Shoot(game_options[SHOT_MAX_ENERGY]/4);
      }
}

void radar(double distance, object_type observed,double angle)
{

	if ((observed==IS_COOKIE)&&(distance<5)){
	
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],parseAng(angle));
	Brake(0.0);
	Accelerate(+game_options[ROBOT_MAX_ACCELERATION]);

	}else if (observed==IS_COOKIE){

	Shoot(1);

	}

	if (observed==IS_ROBOT) {
		timeoutVisto = 0;
		visto = 1;
		Shoot(15);
		seguir(distance,parseAng(angle));
		}else if (visto != 1){
					Brake(0.0);
					Accelerate(+game_options[ROBOT_MAX_ACCELERATION]/2);
					RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-PI/4);
			
		} else if ((visto==1)&&(timeoutVisto<25)){
		
				timeoutVisto++;

			}else {
				
				timeoutVisto = 0;
				visto = 0;

				}

	if ((observed==IS_WALL)&&(distance < 3.5)&&(parseAng(angle)<PI)){

	Brake(1.0);
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-PI/2);

	}else if ((observed==IS_WALL)&&(distance < 3.5)&&(angle>PI)){

	Brake(1.0);
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],PI/2);

	}

	if ((observed==IS_MINE)&&(distance < 4)){

	Shoot(1);
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-parseAng(angle));

	}

	
	if ((shooted=!0)&&(shooted<25)){

	shooted++;

	}else {
		Brake(1.0);
		shooted = 0;
		}

}

void exit_robot()
{
    Print("¡¡¡SPINZAKU!!!");
    exit(1);
}
        
int main()
{
srand(time(NULL));
/* Initializing Callbacks */
Initialize=initialize;
Radar=radar;
Collision = collision;
ExitRobot=exit_robot;
GameOption=game_option;

/* Calling parser */
Scanner();

/* Ouch, parser exited, there was an error */
return 1;
}
