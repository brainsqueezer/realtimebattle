// Returns 1 if something was parsed
int optimized_parser ();
