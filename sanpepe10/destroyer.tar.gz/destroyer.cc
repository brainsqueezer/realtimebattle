/* Robot Destroyer - Alberto Rodr�guez Ferraces (Bertus) */
 
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <math.h>
#include <signal.h>
#include "Messagetypes.h"

using namespace std;

class nodo {
	public:
    	char mensaje[256];
	nodo* psig;
	nodo();
};
	
	
class lista {
	public:
	nodo *l;
	lista();
	void insertar(char msj[256]);
	void mostrar();
};

lista::lista()
{
	l=NULL;
}

void lista::insertar(char msj[256])
{
	nodo *aux;
	nodo *nuevo=(nodo*) malloc (sizeof(nodo));
	if (l==NULL)
		l=nuevo;
	else {
		aux=l;
		while (aux->psig!=NULL) {
			aux=aux->psig;
			}
		aux->psig=nuevo;
		}
	strcpy(nuevo->mensaje,msj);
	nuevo->psig=NULL;
}
  
void lista::mostrar()
{
	char msjaux[256];
	nodo *aux;

	aux=l;
	while (aux!=NULL) {
		strcpy(msjaux,aux->mensaje);
        l=aux->psig;
        free(aux);
		aux=l;
		cout << msjaux << endl;
		}
}

lista lista_msj;

volatile double rotar_robot = 0.0;
volatile double aceleracion = 2.0;

double robot_energy, max_rotate, c_max_rotate;
double r_max_rotate, max_acc, min_acc;
double shot_min_energy, max_shot_energy; 
double tid, velocidad, angulo_radar, angulo_canhon;
double vel, dist_enemy = 10, robot_enemy_energy;
double energia_ant=0; 
double fallos=0, angulo;

int veces_muro = 0;
int signo = -1;
int disparos=0;
int robots_left = 2;
int veces =0, veces2=0;
int cookie = 0;

bool enemy = false, vio_enemigo = false;
bool b = false, disparar = true;

volatile sig_atomic_t exit_robot = false;



message_to_robot_type name2msg_to_robot_type(char* msg_name)
{
	for(int i=0; message_to_robot[i].msg[0] != '\0'; i++)
   	{
		if( strcmp(message_to_robot[i].msg, msg_name) == 0 )
			return (message_to_robot_type)i;
	}
	return UNKNOWN_MESSAGE_TO_ROBOT;
}


void rafaga()
{
	for (int i=0; i<5;i++) {
		cout << "Shoot " << shot_min_energy*5 << endl;
	}
}


void check_messages(int sig)
{
	exit_robot = false;
	
	char msg_name[81];
	char text[81];
	message_to_robot_type msg_t;
	
	cin.clear();
	while( !cin.eof() )
    {
		cin >> msg_name;
		msg_t = name2msg_to_robot_type(msg_name);
		switch(msg_t)
		{
			case ENERGY:
				cin >> robot_energy;
				break;
			case ROBOT_INFO:
				int nada;
				cin >> robot_enemy_energy >> nada;
				if (robot_enemy_energy==energia_ant)
					fallos++;
				else
					fallos=0;	
				energia_ant = robot_enemy_energy;
				
				break;  
			case GAME_OPTION:
				double value;
				int option;
				cin >> option >> value;
				switch(option)
			{
				case ROBOT_MAX_ROTATE:
					max_rotate = value;
					vel = max_rotate;
					break;
				case ROBOT_CANNON_MAX_ROTATE:
			     	c_max_rotate = value;
					break;
				case ROBOT_RADAR_MAX_ROTATE:
			     	r_max_rotate = value;
					break;
				case ROBOT_MAX_ACCELERATION:
			     	max_acc = value;
					break;
				case ROBOT_MIN_ACCELERATION:
			     	min_acc = value;
					break;  
				case SHOT_MIN_ENERGY:
			     	shot_min_energy = value;
					break;
				case SHOT_MAX_ENERGY:
			     	max_shot_energy = value;
					break;
 		      	default:
					break;
			}
				break;
			case INITIALIZE:
				int init;
				cin >> init ;
				if (init == 1)
				{
					cout << "Name Destroyer" << endl;
					cout << "Colour dede11 de5500" << endl;
				}
				break;
			case GAME_STARTS:
				
				cout << "RotateTo 6 " << max_rotate << " " << 0.0 << endl;
				aceleracion = max_acc*0.9;
				cout << "Accelerate " << aceleracion << endl;
				vio_enemigo= false;
				break;
			case GAME_FINISHES:
				break;
				
			case INFO:
				cin >> tid >> velocidad  >> angulo_canhon;
				
				break;
				
			case ROBOTS_LEFT:
				cin >> robots_left;
				break;
				
			case RADAR:
			{
				double dist, energy;
				int object;
				
				cin >> dist >> object >> angulo_radar;
				switch(object)
				{
					case ROBOT:
						enemy = true;
						vio_enemigo = true;
						veces = 0;
						energy = shot_min_energy*4;
						dist_enemy = dist;
						angulo = angulo_radar;
						aceleracion = 0.1;
						
						if (dist<13.0)
						{ 
							if (aceleracion != 0.0)
							{
								aceleracion = 0.0;
								cout << "Accelerate " << aceleracion<< endl;
							}
							if (dist<11.0) 
							{
								energy = max_shot_energy/2;
								cout << "Shoot " << energy << endl;
								
								disparos = disparos++;
								
								
								if (dist<5) 
								{
									cout << "Shoot " << max_shot_energy << endl;
									disparos = disparos++;	
								} 
								
								cout << "Brake " << 1.0 << endl << flush;
								
							}			 
							
						}
						else  
						{
							if (disparar) 
								cout << "Shoot " << energy << endl;
						}
						cout << "Sweep 6 " << max_rotate/2 << 3.1415/7 << -3.1415/7 << endl;
						disparar = !disparar;
						
						break;
					case WALL:
						
						cookie=0;
						
						if (enemy)
						{
							
							veces++;
							
							if (veces%4 ==0) 
							{
								signo = (-1)*signo;
								
							}
							
							
							cout << "Brake " << 1.0 << endl;
							
							cout << "Rotate 6 " << signo*max_rotate/2 << endl;
							
							if (veces==4)  
							{
								enemy = false; 		
								vio_enemigo = true;
								veces_muro = 0;
							} 
							
						}
						else 
						{ 		 
							if ((veces_muro==5)&&(vio_enemigo)) 
							{
								signo = -signo;  
							}
							
							if (vio_enemigo) veces_muro++;
							if (veces_muro == 6) 
							{	    
								veces_muro = 0;
								vio_enemigo = false;	
							}	
							
							if (!vio_enemigo) 
							{									
								if (veces2%40)
									cout << "Brake 0.5" << endl << flush;
								else
									cout << "Brake 0.0" << endl;
								
								aceleracion = max_acc*0.7;
								veces2++;
								cout << "Accelerate " << aceleracion<< endl;
								
							}
							
							if (veces2==1000) 
							{
								signo = -signo;
								veces2 = 0;
							}
							
							cout << "Rotate 7 " << -signo*max_rotate << endl;
							
						}
						break;
						
						
						
					case COOKIE:
						cout << "RotateAmount 1 " << max_rotate  << " " << angulo_radar << endl;
						cookie++;
						enemy = false;
						veces=0;
						aceleracion = max_acc*0.9;
						cout << "Brake " << 0.0 << endl;
						cout << "Accelerate " << max_acc*0.9 << endl;   
						break;
						
					case MINE:
						
						if (dist < 4)
						{
							aceleracion = 0.0;
							rotar_robot = 2.0;
							if (velocidad > 0.4)
								cout << "Brake 1" << endl;
							cout << "Shoot " << shot_min_energy << endl;
							cout << "Accelerate " << aceleracion << endl;
							cout << "Rotate 1 " << rotar_robot << endl;
						}
						break;
					case SHOT:
						break;
				}
				break;
			}
				
			case COLLISION:
			{
				int tmp;
				double energy_diff = 0, coll_angle;
				cin >> tmp >> coll_angle;
				switch(tmp)
				{
					case ROBOT: 
						
						break;
					case SHOT:
						
						break;
					case MINE: 
						cout << "Print Caguen!" << endl; 
						break;
					case COOKIE: 
						cookie=0;
						cout << "Print To pa mi!" << endl; 
						break;
					case WALL:
						break;
				}
				
			}
				break;
			case WARNING:
				cin.getline(text,80,'\n');
				cout << "Print Psssss...  " << text << endl;
          break;
        case EXIT_ROBOT:
          cout << "Ciao!" << endl;
          exit_robot = true;
          break;
        default:
          break;
        }
    }
  signal (sig, check_messages);
}


double radianes2grados (double radianes)
{
	double grados;
	grados=radianes*180.0/3.141592654;
	grados=fmod(grados,360.0);
	if (grados<0)
		grados=grados+360;
	return (grados);
}


int main(int argc, char * argv[])
{
	sigset_t usr1set;
	
	signal(SIGUSR2, check_messages);
	
	sigemptyset(&usr1set);
	sigaddset(&usr1set, SIGUSR2);
	sigprocmask(SIG_UNBLOCK, &usr1set, NULL);
	
	cout << "RobotOption " << SEND_ROTATION_REACHED << " " << 0 << endl;
	cout << "RobotOption " << USE_NON_BLOCKING << " " << 1 << endl;
	cout << "RobotOption " << SIGNAL << " " << SIGUSR2 << endl;
	
	
	for(;;sleep(1))
    {
		if( exit_robot ) 
        {
			return(EXIT_SUCCESS);
        }
    }
	return(EXIT_SUCCESS);
  
}

