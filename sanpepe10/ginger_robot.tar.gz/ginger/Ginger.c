/*Orden de compilacion:
	gcc -combine parser.c rtbapi.c Ginger.c -o Ginger.robot*/

#include <stdio.h>
#include "rtbapi.h"

void initialize (int i)
{
    if (i==1) 
    {
        Name("Ginger");
        Colour(0xff00ff,0xff00ff);
    }
}

void radar(double distance, object_type observed, double angle)
{
     Accelerate(0.7);

    Rotate(ROTATE_ROBOT+ROTATE_CANNON+ROTATE_RADAR, 1);

    if (observed == IS_ROBOT)
    {
        Shoot(7);
        Shoot(7);
        Shoot(7);
        Shoot(7);
        
        Accelerate(1);
    }

    if (observed == IS_MINE)
    {
        Rotate(ROTATE_ROBOT, 4);
        Accelerate (0.2);
    }

    if (observed == IS_COOKIE)
    {
        RotateTo(ROTATE_ROBOT, 1,0); 
        Accelerate (10);
    }
    
    if (observed == IS_WALL)
    {
        Rotate(ROTATE_ROBOT, 3);
        
        Brake(1);
    }

               
}

//De aqui pa abajo no cambies nada
void exitRobot()
{
    exit(1);
}

int main()
{
    Initialize=initialize;
    Radar=radar;
    ExitRobot=exitRobot;
    Scanner();
}
