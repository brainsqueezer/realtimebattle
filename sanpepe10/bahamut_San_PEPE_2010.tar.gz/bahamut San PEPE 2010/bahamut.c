/* This example is part of RTBApi
 * Copyright (C) 1998 Ruben <ryu@mundivia.es>                           
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
#include <stdio.h>
//#include <string.h>
#include <stdlib.h>
#include "rtbapi.h"
#include <math.h>

#define PI 3.14159265358979323846

// Autor del robot - Victor Portela Romero - ingvpr00@udc.es


/*
Compilar: 
   gcc -Wall -lm -combine parser.c rtbapi.c bahamut.c -o bahamut.robot && cp bahamut.robot /usr/lib/realtimebattle/Robots/ && chmod 777 /usr/lib/realtimebattle/Robots/bahamut.robot

*/


//vbles globales

//int cambio = 1;
int vigia = 0;
int visto = 0;
int timeoutVisto = 0;
int shooted = 0;
int muro = 0;
int galleto = 0;
double rotandoA= 0;
double acelerandoA= 0;
double girandoA= 0;
double angDispRec= 0;
double vistoen = 0;


void initialize(int i)
{
    RobotOption(SEND_ROTATION_REACHED,1);
    if (i==1) /* Need to send name and colour */
    {
        Name("Bahamut");
        Colour(0x930606,0x0090ff);
    }
}

#define AMOUNT 0.4

double game_options[32]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

void game_option(game_option_type type, double value)
{

	game_options[type]=value;

}

double parseAng (double ang){
	
	return ((ang/(2*PI))-floor((ang/(2*PI))))*2*PI;

}


void collision (object_type coltype, double angle){

	if (coltype == IS_WALL) {visto = 0;}
	else if ((coltype == IS_SHOT)) 
		{


//		Print("me han disparado");	
		angDispRec = angle;
		shooted = 1;
		
		}

}
/*

void movimientoBase(){

	vigia++;
	if(vigia%200==0){
	cambio++;
	}
	
	if (cambio % 2 == 0)
	{
	Brake(0.0);
	Accelerate(+game_options[ROBOT_MAX_ACCELERATION]/1.5);
	acelerandoA = +game_options[ROBOT_MAX_ACCELERATION]/1.5;
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],PI/4);
	rotandoA = PI/4;
	girandoA = PI/4;
	} else {

	Brake(0.0);
	Accelerate(+game_options[ROBOT_MAX_ACCELERATION]/2);
	acelerandoA = +game_options[ROBOT_MAX_ACCELERATION/2];
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-PI/4);
	rotandoA = -PI/4;
	girandoA = -PI/4;

	}

	char corr[500];
	sprintf(corr,"corriendo 1 y 2 -> %d %d ",vigia,cambio);
	Print(corr);


}


void barrido (){

	if (visto ==0){
	Sweep (ROTATE_RADAR, 2, -PI/4, PI/4);
	}
}*/

void seguir (double distance,double angle){

	Brake(0.0);
	Accelerate(+game_options[ROBOT_MAX_ACCELERATION]);
	acelerandoA = +game_options[ROBOT_MAX_ACCELERATION];
	Shoot(50);
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],angle*1.2);
	rotandoA = +game_options[ROBOT_MAX_ROTATE];
	girandoA = angle*1.2;
	vistoen = angle;
	
}




void radar(double distance, object_type observed,double angle)
{

	//char s[200];
	//sprintf(s,"el timeout visto es %d",timeoutVisto);

	//char dist[500];
	//sprintf(dist,"shooted -> %d ",shooted);
	//Print(dist);


	//char rot[500];
	//sprintf(rot,"rotando a -> %.2f ",rotandoA);
	//Print(rot);

	//char gir[500];
	//sprintf(gir,"girando a -> %.2f",girandoA);
	//Print(gir);

	//char acc[500];
	//sprintf(acc,"acelerando a -> %.2f",acelerandoA);
	//Print(acc);


	if ((shooted!=0)&&(shooted<100)&&(visto!=0)){

	char strng1[500];
	sprintf(strng1,"escapando -> %d",shooted);
	Print(strng1);
	shooted++;
	Brake(0.0);
	Accelerate(game_options[ROBOT_MAX_ACCELERATION]);
	acelerandoA = game_options[ROBOT_MAX_ACCELERATION];
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-1*(parseAng(angDispRec)+PI/2));
	rotandoA = +game_options[ROBOT_MAX_ROTATE];
	girandoA =-1*(parseAng(angDispRec)+PI/2);
	

	}else {
		shooted = 0;
		}

	if ((observed==IS_MINE)&&(distance < 8)&&(shooted==0)){

	Shoot(1);
	Brake(1.0);
	Accelerate(-game_options[ROBOT_MAX_ACCELERATION]/2);
	acelerandoA = -game_options[ROBOT_MAX_ACCELERATION]/2;
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-1*(parseAng(angle)+PI/2));
	rotandoA = +game_options[ROBOT_MAX_ROTATE];
	girandoA = -1*(parseAng(angle)+PI/2);

	} else if ((observed==IS_MINE)&&(distance < 8)){

	Shoot(1);

	}

	
	if ((observed==IS_COOKIE)&&(distance<12)&&(shooted==0)){

	galleto = 1;
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],parseAng(angle));
	rotandoA = +game_options[ROBOT_MAX_ROTATE];
	girandoA = parseAng(angle);
	Brake(0.0);
	Accelerate(+game_options[ROBOT_MAX_ACCELERATION]);
	acelerandoA = +game_options[ROBOT_MAX_ACCELERATION];
	

	}else if ((observed==IS_COOKIE)&&(shooted==0)){

	Shoot(1);
	

	} else {galleto = 0;}


	if (observed==IS_ROBOT) {
		
		shooted = 0;
		timeoutVisto = 0;
		visto = 1;
		seguir(distance,parseAng(angle));

		}else if ((visto != 0)&&(timeoutVisto<20)){

			Brake(0.0);
			Shoot(20);
			Accelerate(+game_options[ROBOT_MAX_ACCELERATION]/1.5);
			acelerandoA = +game_options[ROBOT_MAX_ACCELERATION]/1.5;
			RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],vistoen*1.2);
			rotandoA = +game_options[ROBOT_MAX_ROTATE];
			girandoA = parseAng(vistoen*1.2);
			timeoutVisto++;
	
			
		} 
		else if ((shooted==0)&&(muro==0)&&(galleto==0)) {
			
			timeoutVisto = 0;
			visto = 0;
			Brake(0.0);
			Accelerate(+game_options[ROBOT_MAX_ACCELERATION]/1.5);
			acelerandoA = +game_options[ROBOT_MAX_ACCELERATION]/1.5;
			RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-1*(parseAng(angle)+PI/3));
			rotandoA = +game_options[ROBOT_MAX_ROTATE];
			girandoA = -1*(parseAng(angle)+PI/3);
			
		
	}

	if ((observed==IS_WALL)&&(distance < 5)&&(shooted==0)){
	
	muro++;
	Brake(1.0);
	Accelerate(-game_options[ROBOT_MAX_ACCELERATION]/2);
	acelerandoA = -game_options[ROBOT_MAX_ACCELERATION]/2;
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-1*(parseAng(angle)+PI/2));
	rotandoA = +game_options[ROBOT_MAX_ROTATE];
	girandoA = -1*(parseAng(angle)+PI/2);

	} else {
	Brake(0.0);
	muro = 0;
	}

	
	

	

}

void exit_robot()
{
    Print("Megafulgoooooor!!!");
    exit(1);
}



        
int main()
{
/* Initializing Callbacks */
Initialize=initialize;
Radar=radar;
Collision=collision;
ExitRobot=exit_robot;
GameOption=game_option;

/* Calling parser */
Scanner();

/* Ouch, parser exited, there was an error */
return 1;
}


	
