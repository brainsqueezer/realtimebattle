"""  This class implements a robot skeleton for your real time battle Robots.
You only need to extends this class and redefine some methods to make your
Robot.

There are two method types:

1) Send data to server. This methods don't need to be redefine, you can
use them without a redefinition.

2) Methods invocated when a message arrives from server. You
must redefine this methods, they give special behaviour to the robot.

"""
    
import sys

class Robot:

    ROTATE_ROBOT=1
    ROTATE_CANNON=2
    ROTATE_ROBOT_CANNON=3
    ROTATE_RADAR=4
    ROTATE_ROBOT_RADAR=5
    ROTATE_CANNON_RADAR=6
    ROTATE_ALL=7
                                              
    UNKNOWN_MESSAGE=0
    PROCESS_TIME_LOW=1
    MESSAGE_SENT_IN_ILLEGAL_STATE=2
    UNKNOWN_OPTION=3
    OBSOLETE_KEYWORD=4
    
    ROBOT_MAX_ROTATE=0
    ROBOT_CANNON_MAX_ROTATE=1
    ROBOT_RADAR_MAX_ROTATE=2
    ROBOT_MAX_ACCELERATION=3
    ROBOT_MIN_ACCELERATION=4
    ROBOT_START_ENERGY=5
    ROBOT_MAX_ENERGY=6
    ROBOT_ENERGY_LEVELS=7
    SHOT_SPEED=8
    SHOT_MIN_ENERGY=9
    SHOT_MAX_ENERGY=10
    SHOT_ENERGY_INCREASE_SPEED=11
    TIMEOUT=12
    DEBUG_LEVEL=13
    SEND_ROBOT_COORDINATES=14 

    SEND_SIGNAL=0
    SEND_ROTATION_REACHED=1
    SIGNAL=2
    USE_NON_BLOCKING=3

    IS_NOOBJECT=-1
    IS_ROBOT=0
    IS_SHOT=1
    IS_WALL=2
    IS_COOKIE=3
    IS_MINE=4
    IS_LAST_OBJECT_TYPE=5

    
    def __init__(self,name,colour,away_colour):
        self.name = name
        self.colour = colour
        self.away_colour = away_colour
        
    def RobotOption (self, option, value):
        """Send options to server.
        Parameters:
             option - A constant option
             value  - Value for this constant

        You must not redefine this method.
        """
        print "RobotOption",option,value
        sys.stdout.flush()

    def Name (self, name):
        """Send robot name to server.

        Parameters:
             name - Robot name.

        You must not redefine this method.
        """

        print "Name",name
        sys.stdout.flush()

    def Colour (self, colour, away_colour):
        """Send robot color to server.

        Parameters:
            colour - Preferent color.
            away_colour - Color if there are other robots
                          with the same color.

        Color formats: Hexadecimal and RGB, for example: ff0A1A

        You must not redefine this method.
        """
        
        print "Colour",colour,away_colour
        sys.stdout.flush()

    def Rotate (self, what, angular):
        """Send a message to server for rotate an object
        (radar,cannon or robot)

        Parameters:
             what - A robot object to rotate. (See ROTATE_* constants)
             angular - Angular speed to rotation.

        You must not redefine this method.

        """
        
        print "Rotate",what,angular
        sys.stdout.flush()

    def RotateTo (self, what, angular, end):
        """Send a message to server for rotate a robot object
        but the end of rotation is indicate.

        Parameters:
             what - A robot object to rotate. (See ROTATE_* constants)
             angular - Angular speed to rotation.
             end - End of rotation

        You must NOT redefine this method.
        """
        
        print "RotateTo",what,angular
        sys.stdout.flush()
        
    def RotateAmount (self, what, angular, angle):
        """Send a message to server to rotate a robot object
        but the amount ( angle ) is indicated.

        Parameters:
             what - A robot object to rotate. (See ROTATE_* constants)
             angular - Angular speed to rotation.
             angle - Angle to rotate.

        You must NOT redefine this method.

        """
        print "RotateAmount",what, angular, angle
        sys.stdout.flush()

    def Sweep(self, rotate_type, angular, left, right):
        """Send a message to establish a rotation method to cannon
        or radar ( not for robot)

        Parameters:
             rotate_type - Type of rotation for robot object.
             angular - Rotation speed
             left - Rotation left angle
             right - Rotation right angle 

        You must NOT redefine this method.

        """
        print "Sweep",rotate_type, angular, left, right
        sys.stdout.flush()
    
    def Accelerate(self, value):
        """Send a message to the server to establish robot speed.

        Parameters:
             value - Robot speed.

        You must NOT redefine this method.

        """
        print "Accelerate", value
        sys.stdout.flush()
    
    def Brake(self, portion):
        """Send a message to the server to establish brake amount.

        Parameters:
             portion - Amount of "brake"

        You must NOT redefine this method.
        """
        
        print "Brake",portion
        sys.stdout.flush()

    def Shoot(self, energy ):
        """Send a message to the server to shoot.

        Parameters:
             energy - Shoot energy ( remember that if you shoot with
                      a lot of energy, your life decreases quickly)
                      
        You must NOT redefine this method.
        """
        print "Shoot", energy
        sys.stdout.flush()

    def Print(self, message):
        """Print a message at window message

        Parameters:
             message - Message string.

        You must NOT redefine this method.

        """
        
        print "Print", message
        sys.stdout.flush()

    def Debug(self, message):
        """Print a message to debug

        Parameters:
             message - Message to show

        You must NOT redefine this method.
        """
        print "Debug", message
        sys.stdout.flush()

    def DebugLine(self, angle1, radius1, angle2, radius2):
        print "DebugLine", angle1, radius1, angle2, radius2
        sys.stdout.flush()

    def DebugCircle(self, center_angle, center_radius, circle_radius):
        print "DebugCircle", center_angle, center_radius, circle_radius


    def Initialize(self, first):
        """ This method initialize the robot. If you want to insert your
        code, you must insert it and call the super class method.

        For example:

        def Initializes(self,first):
            self.Print("Hello!")
            Robot.Initialize(first)

        You could redefine this method.
        """
        
        self.Name(self.name)
        self.Colour(self.colour,self.away_colour)

    def YourName(self, name):
        """ This function is activated when arrives a
        server message with your name.

        Parameters:

            name - Name send by server

        You could redefine this method.
        """
        return

    def YourColour(self,name):
        """ This function is activated when arrives a
        server message with your colour.

        Parameters:

            colour - Colour send by server

        You could redefine this method.
        """
        return

    def GameOption(self, gameoption, value):
        return

    def GameStarts(self):
        """This function is activated when the game start.

        No parameters.

        You could redefine this method.
        """
        return

    def Radar (self, distance, object, radar_angle):
        return
        """This function is activated when robot radar see
           an object ( wall, other robot, a cookie or a mine ).

           distance : Distance between robot and object
           object: Object that had been seen
           radar_angle: Radar angle when the object had been seen.

           You could redefine this method.
           """
    
    def Info (self, time, speed, angle):
        return

    def Coordinates (self, x, y, angle):
        return

    def RobotInfo(self, energy_level, teammate):
        return

    def RotationReached(self, rotate_type):
        return

    def Energy(self, energy_level):
        return

    def RobotsLeft(self, robots_number):
        return

    def Collision(self, object, angle_relative):
        return

    def Warning(self, warning_type, message):
        return

    def Dead(self):
        return

    def GameFinishes(self):
        return

    def ExitRobot(self):
        return

        
    def OptimizedParser (self):
        line=sys.stdin.readline()    
        parameters=line.split()


        if len(line) < 2 :
            return

        else:
            command=parameters[0]

    

        if(command == ""):
            return

        elif(command == "Initialize"):
            self.Initialize(int(parameters[1]))

        elif(command == "YourName"):
            self.YourName(parameters[1])

        elif(command == "YourColour"):
            self.YourColour(parameters[1])

        elif(command == "GameOption"):
            self.GameOption(int(parameters[1]), float(parameters[2]))

        elif(command == "GameStarts"):
            self.GameStarts()

        elif(command == "Radar"):
            self.Radar(float(parameters[1]),int(parameters[2]),float(parameters[3]))

        elif(command == "Info"):
            self.Info(float(parameters[1]),float(parameters[2]),float(parameters[3]))

        elif(command == "Coordinates"):
            self.Coordinates(float(parameters[1]),float(parameters[2]),float(parameters[3]))

        elif(command == "RobotInfo"):
            self.RobotInfo(float(parameters[1]),int(parameters[2]))

        elif(command == "RotationReached"):
            self.RotationReached(int(parameters[1]))

        elif(command == "Energy"):
            self.Energy(float(parameters[1]))

        elif(command == "RobotsLeft"):
            self.RobotsLeft(int(parameters[1]))

        elif(command == "Collision"):
            self.Collision(int(parameters[1]),float(parameters[2]))

        elif(command == "Warning"):
            self.Warning(int(parameters[1]), parameters[2])

        elif(command == "Dead"):
            self.Dead()

        elif(command == "GameFinishes"):
            self.GameFinishes()

        elif(command == "ExitRobot"):
            self.ExitRobot()

        else:
            print "WARNING!!! Unknown Command: [ ", command , " ] "

    
    def Scanner (self):
        self.RobotOption(2, 0);
        self.RobotOption(1, 1);
        self.RobotOption(3, 0);

        while(1):
            self.OptimizedParser()

    
        





        
