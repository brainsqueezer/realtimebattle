/*
Robot creado por Paul Rodga basandose en la libreria libre GNU Library General Public de Ruben, RTBApi.
Puede ser utilizado de cualquier forma (duplicado, modificado,...) siempre que se diga quien es su autor.
*/

#include "../rtbapi.h"

#define PI 3.14159265359

#include <stdio.h>
#include<time.h>

void initialize(int i)
{
  RobotOption(SEND_ROTATION_REACHED,1);
  if (i==1) /* Need to send name and colour */
    {
      Name("RodgaNator v0.8.1");
      Colour(0x114011,0x114011);
    }
}

#define AMOUNT 0.4

double game_options[32]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

time_t timerR;
time_t timerC;
double total=0;

void game_option(game_option_type type, double value)
{
  game_options[type]=value;
}


void collision(object_type objeto, double angulo){
  
  if (objeto==IS_ROBOT){
    Accelerate(game_options[ROBOT_MAX_ACCELERATION]);
    Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);
  }
  
  if (objeto==IS_COOKIE){
    Print("Que rica galletita!");
    Brake(0.0);
    Accelerate(game_options[ROBOT_MAX_ACCELERATION]);
    Rotate(ROTATE_ROBOT,-game_options[ROBOT_MAX_ROTATE]);
  }
  
  if (objeto==IS_WALL){
    Accelerate(game_options[ROBOT_MIN_ACCELERATION]);
    Rotate(ROTATE_ROBOT,-game_options[ROBOT_MAX_ROTATE]);
  }
  
  if (objeto==IS_MINE){
    //Accelerate(game_options[ROBOT_MIN_ACCELERATION]);
    //Rotate(ROTATE_ROBOT,-game_options[ROBOT_MAX_ROTATE]);
    Print("Mierda!");
  }
  
  
}


void radar(double distance, object_type observed,double angle)
{
  if (observed==IS_ROBOT) 
    {
      if (distance<3) Shoot(SHOT_MAX_ENERGY); 
      else Shoot(100/distance);
      Brake(0.0);//0.5
      Accelerate(game_options[ROBOT_MIN_ACCELERATION]/2);    ////////////
      Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);  ////////////
    }
  if (observed==IS_SHOT) 
    {
      Rotate(ROTATE_ROBOT,-game_options[ROBOT_MAX_ROTATE]);
      Accelerate(game_options[ROBOT_MAX_ACCELERATION]);    //////////
      Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);
      Brake(0.0);
    }
  if (observed==IS_WALL) 
    {
      Rotate(ROTATE_ROBOT,-game_options[ROBOT_MAX_ROTATE]);
      Accelerate(game_options[ROBOT_MAX_ACCELERATION]);
      Brake(0.5);
    }

      //timer1=time(NULL);
      //timer2=time(NULL);
      //total=difftime(timer2, timer1);

  if ((observed==IS_COOKIE)) ///////// && ((ROBOT_ENERGY_LEVELS<50)||distance<10)
    {
      timerC=time(NULL);
      total=difftime(timerC, timerR);

      if(total>1){
       Print("Veo COOKIE y cumplo!");
       Accelerate(game_options[ROBOT_MAX_ACCELERATION]); // /3
       Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);     
       Brake(0.0);
       if(distance<2){
       Brake(0.8);
       Accelerate(game_options[ROBOT_MIN_ACCELERATION]);
       usleep(800000);
       Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);  //-/////////////
       Accelerate(game_options[ROBOT_MAX_ACCELERATION]);
       }
      }
    }
  if (observed==IS_MINE && distance <2) /////////////
    {
      Shoot(SHOT_MIN_ENERGY);
      Brake(0.2);
      Accelerate(game_options[ROBOT_MAX_ACCELERATION]/3);  /////////////////
      Rotate(ROTATE_ROBOT,-game_options[ROBOT_MAX_ROTATE]);
    }
}

void exit_robot()
{
  Print("Muerte Asesinato!!!");
  exit(1);
}
        
int main()
{
/* Initializing Callbacks */
Initialize=initialize;
Collision=collision;
Radar=radar;
ExitRobot=exit_robot;
GameOption=game_option;

/* Calling parser */
Scanner();

/* Ouch, parser exited, there was an error */
return 1;
}
