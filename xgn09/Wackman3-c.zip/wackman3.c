/* 

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU Library General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public
License along with this program; if not, write to the
Free Software Foundation, Inc., 59 Temple Place - Suite 330,
Boston, MA  02111-1307, USA. */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <Messagetypes.h>

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#define pi 3.14159
#define vuelta 2*pi

char* mensaje;
int objeto;
double distancia, angulo;
double angulo;

/* Se ejecuta cuando se detecta un robot */
void robot_detectado()
{
   /* vamos a intentar girar y darle */
   printf("RotateAmount 7 0.9 %lf\n",angulo);
   if(distancia<7) /* Para economizar, solo disparamos con mas potencia y dos tiros si está muy cerca */
   {
      printf("Shoot 2\n");
      printf("Shoot 2\n");
      if(distancia <3)
      {
         printf("Shoot 4\n");
         printf("Shoot 2\n");
      }
      fflush(stdout);
   }
   else /* Si esta algo mas lejos nos vale con solo un tiro.. no esta la cosa para desperdiciar :-) */
   {
      printf("Shoot 2\n");
   }  
   printf("Accelerate 0.6\n");
   printf("Sweep 7 0.9 -1 1\n");
   /* printf("Print enemigo en %lf\n",angulo); */
   fflush(stdout);
   
}


/* Se ejecuta cuando se detecta un disparo */
void disparo_detectado()
{
   /* No gastamos demasiada energía, a lo mejor ni nos va a dar */
   printf("Shoot 1\n"); 

}


/* Se ejecuta cuando se detecta un muro */
void muro_detectado()
{
   if(distancia<5.0)
   {
        printf("RotateAmount 7 0.9 1.0\n");
        printf("Accelerate 0.5\n");
        printf("Sweep 7 0.9 -1.0 1.0\n"); 
        fflush(stdout);
   }
   else
   {
        
   }
   
}


/* Se ejecuta cuando se detecta galleta de energía */
void galleta_detectada()
{
   
}


/* Se ejecuta cuando se detecta una mina frente al radar */
void mina_detectada()
{
   
}

/* Se ejecuta cuando recibe un golpe */
void colision()
{
   switch(objeto)
   {
      case 0: /*Colision con un robot*/
         printf("Print desgraciado, te voy a dar p'al pelo!!!\n");
         printf("RotateAmount 7 0.9 %lf\n",angulo);
         if((angulo<1)&&(angulo>-1))
         {
            printf("Shoot 2\n");
         }
         fflush(stdout);
      break;

      case 1: /*Colision con un disparo*/
         printf("Print Arghhh me ha dado!!\n");
         printf("RotateAmount 7 0.9 0.5\n",angulo);
         /*printf("RotateAmount 7 0.9 %lf\n",angulo);*/
         printf("Shoot 2\n");
         fflush(stdout);
      break;
  
      case 2: /*Colision con un muro*/
         printf("Print Ostia!, si habia un muro aqui!!!\n");
      break;

      case 3: /*Galleta cogida */
         printf("Print Ñam!!!\n");
      break;

      case 4: /*Colision con una mina*/
         printf("Print Dios mio, no siento las piernas!!!\n");
      break;
      
   }

}


/* Este bucle va comprobando mensajes desde stdin de forma contínua hasta
   que encuentra uno, lo interpreta y obra en consecuencia */ 
void bucle_principal()
{
   mensaje=malloc(256*sizeof(char)); /* Reservamos algo de espacio para el mensaje*/

   while(1) /* Bucle contínuo*/
   {
      if(!feof(stdin)) /* Si hay alguna mensaje del programa lo coge */
      {
         gets(mensaje);
         fflush(stdin);
         /* Comenzamos a comparar mensajes */
         if (strncmp(mensaje,"GameStarts",10)==0)
         {
              printf("Accelerate 0.2\n");
              printf("Sweep 7 0.9 -1 1\n"); /* Comenzamos a rotar el cañón y el radar a la vez */
              fflush(stdout);
         }
         /* Manejamos los eventos recibidos del Radar */
         else if(strncmp(mensaje,"Radar",5)==0) /* El radar ha detectado algo, hay que seleccionar */
         {
            sscanf(mensaje,"Radar %lf %i %lf",&distancia,&objeto,&angulo);
            switch (objeto)
            {
            case 0: /*Robot detectado*/
               robot_detectado();
	       break;
          
            case 1: /*disparo en camino */
               disparo_detectado();
               break;
             
            case 2: /* Muro */
               muro_detectado();
               break;
           
            case 3: /*Galleta :-) */
               galleta_detectada();
               break;

            case 4: /*Mina*/
               mina_detectada();
               break;

            case 5: /* Sigue ahi el mismo objeto */
               break;
            }

         }
         else if(strncmp(mensaje,"Collision",9)==0)
         {
            /*Acabamos de golpearnos con algo */
            sscanf(mensaje,"Collision %i %lf",&objeto,&angulo);
            colision();
         }

      
      }
      else /* Si no hay mensajes espera */
      {

         /* De momento no hacemos nada */
      }
   }
}

/* la típica entrada :-) */
int main(int argc, char * argv[])
{
  /* Parametros del robot*/
  /* printf("RobotOption %i 0\n",USE_NON_BLOCKING); */
  printf("Name Wackman3\n");
  fflush(stdout);
  printf("Colour ffff00 00ff00\n"); /* Color a emplear y alternativo por si esta ocupado */
  fflush(stdout);


  bucle_principal();


  return(EXIT_SUCCESS);
}

