/*
Robot de María Rodríguez nº1856
Basado en la libreria de Ruben RTBApi, libreria con licencia publica GNU GPL

Se ceden los derechos de publicación, utilización y modificación de este código fuente.
*/

#include "../rtbapi.h"

#define PI 3.14159265359

#include <stdio.h>

void initialize(int i)
{
  RobotOption(SEND_ROTATION_REACHED,1);
  if (i==1) /* Need to send name and colour */
    {
      Name("Maria");
      Colour(0xFFFF00,0xFFFF00);
    }
}

#define AMOUNT 0.4

double game_options[32]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

void game_option(game_option_type type, double value)
{
  game_options[type]=value;
}

void radar(double distance, object_type observed,double angle)
{
  if (observed==IS_ROBOT) 
    {
      Shoot(100/distance);
      Brake(0.5);
      Accelerate(game_options[ROBOT_MAX_ACCELERATION]/3);
      Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);
    }
  if (observed==IS_SHOT) 
    {
      //Shoot(game_options[SHOT_MAX_ENERGY]/(1.5*distance));
      Rotate(ROTATE_ROBOT,-game_options[ROBOT_MAX_ROTATE]);
      Accelerate(game_options[ROBOT_MAX_ACCELERATION]/10);
      Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);
      Brake(0.0);
    }
  if (observed==IS_WALL) 
    {
      Rotate(ROTATE_ROBOT,-game_options[ROBOT_MAX_ROTATE]);
      Accelerate(game_options[ROBOT_MAX_ACCELERATION]);
      Brake(0.5);
    }
  if (observed==IS_COOKIE && distance < 6) 
    {
      Brake(0.0);
      Accelerate(game_options[ROBOT_MAX_ACCELERATION]/3);
      Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);
    }
  if (observed==IS_MINE && distance<3) 
    {
      Shoot(1);
      Brake(0.0);
      Accelerate(game_options[ROBOT_MAX_ACCELERATION]/3);
      Rotate(ROTATE_ROBOT,game_options[ROBOT_MAX_ROTATE]);
    }
}

void exit_robot()
{
  Print("Muere!!!");
  exit(1);
}
        
int main()
{
/* Initializing Callbacks */
Initialize=initialize;
Radar=radar;
ExitRobot=exit_robot;
GameOption=game_option;

/* Calling parser */
Scanner();

/* Ouch, parser exited, there was an error */
return 1;
}
