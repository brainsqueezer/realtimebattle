Para generar el robot Maria.robot hágase make en la carpeta robots, es posible que haya que darle todos los permisos para su correcto funcionamiento.
