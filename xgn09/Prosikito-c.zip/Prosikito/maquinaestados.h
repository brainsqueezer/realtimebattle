#ifndef N_MAQUINAESTADOS_H
#define N_MAQUINAESTADOS_H

#undef N_DEFINES
#define N_DEFINES nMaquinaEstados

enum TAlfabetoEntrada
{
	BUSCAR,
	ATAQUE_KAMIKAZE,
	ATAQUE_PREVENTIVO,
	COGER_GALLETA,
	HUIR
};

enum TEstado
{
	BUSQUEDA,
	KAMIKAZE,
	PREVENTIVO,
	HAMBRIENTO,
	CAGUETA
};

//------------------------------------------------------------------------------
class nMaquinaEstados
{
public:
	/// constructor
	nMaquinaEstados();
	/// destructor
	virtual ~nMaquinaEstados();    
	
	bool NextStatus(int in);
	int GetStatus();
	void SetStatus(int estado);

private:
	int  estado_actual;
};

#endif
