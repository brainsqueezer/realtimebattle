#define N_IMPLEMENTS nIA

#include "nia.h"
#include "Messagetypes.h"
#include <math.h>

#define abs(x) ((x>0) ? (x) : -(x))
#define sgn(x) ((x>0) ? 1 : -1)
#define max(a,b) (((a) > (b)) ? (a) : (b))
#define min(a,b) (((a) < (b)) ? (a) : (b))
#define mod(a,b) ( a - floor( a / b ) * b )
#define exp(a) ( a * a )

//------------------------------------------------------------------------------
/**
*/
nIA::nIA()
{
	escritor = new nEscritor();
	estado 	 = new nMaquinaEstados();
	estado_anterior = BUSQUEDA;
}

//------------------------------------------------------------------------------
/**
*/
nIA::~nIA()
{
	delete escritor;
	delete estado;
}

/**
*/
bool nIA::Run(nMemoria *memoria)
{
	switch ( memoria->GetLastMessage() )
	{
		case INITIALIZE:
			if ( !memoria->GameStarted() )
			{
				if ( memoria->GetSecNumber() == 1 )
				{
					escritor->Initialize("Prosikito","33FF33","3333FF");
				}
			}
			break;
		case GAME_STARTS:
			estado->SetStatus( BUSQUEDA );
			estado_anterior = BUSQUEDA;
			memoria->Init();
			break;
		case NAME:
			escritor->Initialize("Prosikito","33FF33","3333FF");
			break;
		default:
			break;
	}
	
	if ( memoria->GameStarted() )
	{
		UpdateStatusMachine( memoria );
		
		if ( estado_anterior != estado->GetStatus()  )
		{
			memoria->ResetStateTime( );
		}
		
		ExecuteSpeedBehavior( memoria );
		ExecuteRadarBehavior( memoria );
		ExecuteRobotBehavior( memoria );
		ExecuteShotBehavior( memoria );
		
		if ( estado_anterior != estado->GetStatus()  )
		{
			estado_anterior = estado->GetStatus() ;
		}
	}
	
	return memoria->GameActive();
}


void nIA::UpdateStatusMachine(nMemoria *memoria)
{
	if ( (memoria->GetLastObjective() == ROBOT ||
		  (memoria->GetNearestEnemySightTime() <1.0 && memoria->GetLastObjective() == SHOT ) ) &&
		  estado->NextStatus( ATAQUE_KAMIKAZE )	)
	{
		estado->SetStatus( KAMIKAZE );
		return;
	}
	if ( 	memoria->GetLastObjective() == MINE && 
		memoria->GetNearestMineSightTime() <= 2.0 &&
		memoria->GetNearestMineDistance() <= 4.0 &&
		!memoria->MineTaken() &&
		estado->NextStatus( ATAQUE_PREVENTIVO )	)
	{
		estado->SetStatus( PREVENTIVO );
		return;
	}

	if ( memoria->GetLastObjective() == WALL &&
		memoria->GetNearestEnemySightTime() >= 1.0 &&
		memoria->GetNearestShotSightTime() >= 1.0 &&
		estado->NextStatus( BUSCAR )	)
	{
		estado->SetStatus( BUSQUEDA );
		return;
	}
}

void nIA::ExecuteSpeedBehavior(nMemoria *memoria)
{;
	switch ( estado->GetStatus() )
	{
		case BUSQUEDA:
			if ( estado->GetStatus() != estado_anterior)
			{
				escritor->Print("Busqueda");	
			}
						
			if ( memoria->GetNearestWallDistance() < 3.0 )
					memoria->SetRobotMaxSpeed( 0.5 );
					
			if (memoria->GetRobotSpeed() < 0.5 )
					memoria->SetRobotMaxSpeed( 5.0 + 5.0 * memoria->GetNearestEnemySightTime() );
					
			break;

		case KAMIKAZE:
			if ( estado->GetStatus() != estado_anterior)
			{
				escritor->Print("¡¡¡KAMIKAZE!!!");	
			}
						
			memoria->SetRobotMaxSpeed( 10.0 );
			break;

		case PREVENTIVO:
			if ( estado->GetStatus() != estado_anterior)
			{
				escritor->Print("Ataque preventivo");	
			}
						
			memoria->SetRobotMaxSpeed( 0.5 );
			break;

		case HAMBRIENTO:
			if ( estado->GetStatus() != estado_anterior)
			{
				escritor->Print("Mmm Galletas...");	
			}
						
			memoria->SetRobotMaxSpeed( 0.1 );
			break;

		case CAGUETA:
			if ( estado->GetStatus() != estado_anterior)
			{
				escritor->Print("Mamaaaa miedooo!!!");	
			}
						
			memoria->SetRobotMaxSpeed( 2.0 );
			break;

		default:
			if ( estado->GetStatus() != estado_anterior)
				escritor->Print("¿Estoy en otro estado?");			
			break;
	}
	// Aceleramos hasta un máximo
	if ( memoria->GetRobotSpeed() < memoria->GetRobotMaxSpeed() )
	{
		escritor->Accelerate( 5.0 );
	}
	else
	{
		escritor->Accelerate( 0.0 );
		escritor->Brake( 1.0 );
	}
}

void nIA::ExecuteShotBehavior(nMemoria *memoria)
{
	double fuerza_disparo;
	switch ( estado->GetStatus() )
	{
	
		case BUSQUEDA:
		case CAGUETA:
			if ( memoria->GetTimesEnemySeen() >2)
			{
				escritor->Shoot( memoria->GetShotMaxEnergy() );
				memoria->ResetTimesEnemySeen();
			}
			break;
				
		case KAMIKAZE:
			if ( memoria->GetTimesEnemySeen() >2)
			{
				escritor->Shoot( memoria->GetShotMaxEnergy() );
				memoria->ResetTimesEnemySeen();
			}
			break;

		case PREVENTIVO:
			if ( memoria->GetNearestMineDistance() <= 4.0 && memoria->GetLastObjective() == MINE )
			{
				escritor->Shoot( memoria->GetShotMinEnergy() );
			}
			break;
		default:
			break;
	}
}

void nIA::ExecuteRadarBehavior(nMemoria *memoria)
{
	double angulo_busqueda;

	switch ( estado->GetStatus() )
	{
		case BUSQUEDA:
			angulo_busqueda =  -sgn(memoria->GetPrevEnemyAngle())*M_PI;
			escritor->RotateAmount( ROTAR_RADAR + ROTAR_ARMA, memoria->GetRobotRadarMaxRotate(), angulo_busqueda);
			break;
			
		case KAMIKAZE:
			angulo_busqueda = memoria->GetNearestEnemyAngle() + (M_PI / 10.0)*sgn(memoria->GetNearestEnemyAngle());
			escritor->Sweep( ROTAR_RADAR + ROTAR_ARMA, memoria->GetRobotRadarMaxRotate(), angulo_busqueda - ( M_PI / 20.0), angulo_busqueda + ( M_PI / 20.0));
			break;			
	}
}

void nIA::ExecuteRobotBehavior(nMemoria *memoria)
{
	double angulo_giro;

	switch ( estado->GetStatus() )
	{
		case BUSQUEDA:	
			angulo_giro =  memoria->GetRobotMaxRotate();	

			escritor->RotateAmount( ROTAR_ROBOT,  memoria->GetRobotMaxRotate(), angulo_giro );
			memoria->SetRotationSpeed( angulo_giro );
			break;

		case KAMIKAZE:
			// Rotamos hacia el cañon		
			angulo_giro =  memoria->GetNearestEnemyAngle() - (M_PI / 10.0)*sgn(memoria->GetNearestEnemyAngle()) ;	
			escritor->RotateTo( ROTAR_ROBOT,  memoria->GetRobotMaxRotate(), angulo_giro);	

			memoria->SetRotationSpeed( memoria->GetPrevEnemyAngle() );
			break;
		
		default:
			if ( memoria->GetNearestEnemyAngle() != 0.0 ) 
			{			
				angulo_giro = memoria->GetRobotMaxRotate() * sgn( memoria->GetNearestEnemyAngle() );
			}
			else
			{
				angulo_giro = memoria->GetRobotMaxRotate() ;
			}

			escritor->RotateAmount( ROTAR_ROBOT,  memoria->GetRobotMaxRotate(), angulo_giro );
			memoria->SetRotationSpeed( angulo_giro );
			break;
	}
}
