/* This example is part of RTBApi
 * Copyright (C) 1998 Ruben <ryu@mundivia.es>                           
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
#include <stdio.h>
//#include <string.h>
#include <stdlib.h>
#include "rtbapi.h"
#include <math.h>

#define PI 3.14159265358979323846



/*
Compilar: 
   gcc -Wall -lm -combine parser.c rtbapi.c bahamut.c -o bahamut.robot && cp bahamut.robot /usr/lib/realtimebattle/Robots/ && chmod 777 /usr/lib/realtimebattle/Robots/bahamut.robot

*/


//vbles globales

int visto = 0;
int timeoutVisto = 0;
int shooted=0;

void initialize(int i)
{
    RobotOption(SEND_ROTATION_REACHED,1);
    if (i==1) /* Need to send name and colour */
    {
        Name("Bahamut");
        Colour(0x930606,0x0090ff);
    }
}

#define AMOUNT 0.4

double game_options[32]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

void game_option(game_option_type type, double value)
{

	game_options[type]=value;

}

double parseAng (double ang){

	return ((ang/(2*PI))-floor((ang/(2*PI))))*2*PI;

}


void collision (object_type coltype, double angle){

	if (coltype == IS_WALL) visto = 0;
	else if ((coltype == IS_SHOT)) 
		{
	
		char s[200];
		sprintf(s,"me han disparado ");
		Print(s);			
		Brake(0.0);
		shooted++;
		Accelerate(game_options[ROBOT_MAX_ACCELERATION]);
		RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-parseAng(angle)/8);
		
		}

}


void barrido (){

	if (visto ==0){
	Sweep (ROTATE_RADAR, 2, -PI/4, PI/4);
	}
}

void seguir (double distance,double angle){
	Brake(0.0);
	Accelerate(+game_options[ROBOT_MAX_ACCELERATION]);
	RotateTo (ROTATE_CANNON, +game_options[ROBOT_MAX_ROTATE],angle);
	Shoot(30);
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],angle);
	


}




void radar(double distance, object_type observed,double angle)
{
	
	//char s[200];
	//sprintf(s,"el timeout visto es %d",timeoutVisto);
	//Print(s);

	if ((observed==IS_COOKIE)&&(distance<5)){
	
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],parseAng(angle));
	Brake(0.0);
	Accelerate(+game_options[ROBOT_MAX_ACCELERATION]);

	}else if (observed==IS_COOKIE){

	Shoot(1);

	}

	if (observed==IS_ROBOT) {
		//barrido();
		timeoutVisto = 0;
		visto = 1;
		Shoot(15);
		seguir(distance,parseAng(angle));
		}else if (visto != 1){
					Brake(0.0);
					Accelerate(+game_options[ROBOT_MAX_ACCELERATION]/2);
					RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-PI/4);
			
		} else if ((visto==1)&&(timeoutVisto<25)){
		
				timeoutVisto++;

			}else {
				
				timeoutVisto = 0;
				visto = 0;

				}

	if ((observed==IS_WALL)&&(distance < 2)&&(parseAng(angle)<PI)){

	Brake(1.0);
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-PI/2);

	}else if ((observed==IS_WALL)&&(distance < 2)&&(angle>PI)){

	Brake(1.0);
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],PI/2);

	}

	if ((observed==IS_MINE)&&(distance < 4)){

	Shoot(1);
	RotateAmount(ROTATE_ROBOT,+game_options[ROBOT_MAX_ROTATE],-parseAng(angle));

	}

	
	if ((shooted=!0)&&(shooted<25)){

	shooted++;

	}else {
		Brake(1.0);
		shooted = 0;
		}

}

void exit_robot()
{
    Print("Megafulgoooooor!!!");
    exit(1);
}



        
int main()
{
/* Initializing Callbacks */
Initialize=initialize;
Radar=radar;
Collision=collision;
ExitRobot=exit_robot;
GameOption=game_option;

/* Calling parser */
Scanner();

/* Ouch, parser exited, there was an error */
return 1;
}


	
